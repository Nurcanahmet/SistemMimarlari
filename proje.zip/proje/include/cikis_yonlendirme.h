#ifndef CIKIS_YONLENDIRME_H
#define CIKIS_YONLENDIRME_H

void cikis_yonlendir(const char* komut);

#endif
