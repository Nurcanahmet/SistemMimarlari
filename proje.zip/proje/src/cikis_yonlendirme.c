#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include "cikis_yonlendirme.h"

void cikis_yonlendir(const char* komut) {
    int dosya = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (dosya == -1) {
        perror("Dosya açılamadı");
        return;
    }

    // Komutu çalıştırmadan önce çıktıyı dosyaya yönlendirme
    dup2(dosya, STDOUT_FILENO);
    close(dosya);

    system(komut);  // Komutu çalıştır
}
