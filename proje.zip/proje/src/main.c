#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();  // Yeni bir süreç oluşturuyoruz

    if (pid == 0) {
        // Alt süreçte çalışacak kod
        execlp("ls", "ls", (char *)NULL);  // ls komutunu çalıştırıyoruz
        // execlp başarısız olursa hata mesajı
        perror("exec failed");
        exit(1);
    } else if (pid > 0) {
        // Ana süreçte yapılacak işlem
        wait(NULL);  // Çocuk süreç bitene kadar bekliyoruz
    } else {
        // fork() hatası
        perror("fork failed");
        exit(1);
    }

    return 0;
}

